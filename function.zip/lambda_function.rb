require 'json'
# require "active_record"

def lambda_handler(event:, context:)
  r = {
    version: "gem check1  ruby version= #{RUBY_VERSION}",
#    rails_version: "ActiveRecord.class is #{ActiveRecord}",
    endless: [0, 1, 2][0..]
  }
  { statusCode: 200, body: JSON.generate(r) }
end
